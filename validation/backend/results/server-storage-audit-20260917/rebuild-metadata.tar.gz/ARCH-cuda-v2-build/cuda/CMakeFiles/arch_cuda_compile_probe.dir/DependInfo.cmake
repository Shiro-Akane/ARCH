
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/tests/cuda/test_cuda_compile_probe.cu" "CMakeFiles/arch_cuda_compile_probe.dir/tests/cuda/test_cuda_compile_probe.cu.o" "gcc" "CMakeFiles/arch_cuda_compile_probe.dir/tests/cuda/test_cuda_compile_probe.cu.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
