# Empty compiler generated dependencies file for arch_cuda_hydro_block.
# This may be replaced when dependencies are built.
