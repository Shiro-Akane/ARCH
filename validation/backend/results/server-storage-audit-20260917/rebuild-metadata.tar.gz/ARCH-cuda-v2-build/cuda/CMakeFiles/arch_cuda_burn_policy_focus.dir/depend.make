# Empty dependencies file for arch_cuda_burn_policy_focus.
# This may be replaced when dependencies are built.
