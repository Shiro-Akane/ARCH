file(REMOVE_RECURSE
  "CMakeFiles/arch_cuda_burn_policy_parity_strict.dir/tests/cuda/test_burn_policy_parity.cu.o"
  "CMakeFiles/arch_cuda_burn_policy_parity_strict.dir/tests/cuda/test_burn_policy_parity.cu.o.d"
  "arch_cuda_burn_policy_parity_strict"
  "arch_cuda_burn_policy_parity_strict.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA CXX)
  include(CMakeFiles/arch_cuda_burn_policy_parity_strict.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
