file(REMOVE_RECURSE
  "CMakeFiles/arch_cuda_compile_probe.dir/tests/cuda/test_cuda_compile_probe.cu.o"
  "CMakeFiles/arch_cuda_compile_probe.dir/tests/cuda/test_cuda_compile_probe.cu.o.d"
  "arch_cuda_compile_probe"
  "arch_cuda_compile_probe.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA)
  include(CMakeFiles/arch_cuda_compile_probe.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
