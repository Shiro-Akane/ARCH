file(REMOVE_RECURSE
  "CMakeFiles/arch_cuda_hydro_leaf_parity.dir/tests/cuda/test_hydro_leaf_parity.cu.o"
  "CMakeFiles/arch_cuda_hydro_leaf_parity.dir/tests/cuda/test_hydro_leaf_parity.cu.o.d"
  "arch_cuda_hydro_leaf_parity"
  "arch_cuda_hydro_leaf_parity.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA)
  include(CMakeFiles/arch_cuda_hydro_leaf_parity.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
