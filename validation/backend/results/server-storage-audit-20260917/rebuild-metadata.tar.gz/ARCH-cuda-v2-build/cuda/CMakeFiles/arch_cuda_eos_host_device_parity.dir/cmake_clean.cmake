file(REMOVE_RECURSE
  "CMakeFiles/arch_cuda_eos_host_device_parity.dir/tests/cuda/test_eos_host_device_parity.cu.o"
  "CMakeFiles/arch_cuda_eos_host_device_parity.dir/tests/cuda/test_eos_host_device_parity.cu.o.d"
  "arch_cuda_eos_host_device_parity"
  "arch_cuda_eos_host_device_parity.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA CXX)
  include(CMakeFiles/arch_cuda_eos_host_device_parity.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
