file(REMOVE_RECURSE
  "CMakeFiles/arch_cuda_backend.dir/src/cuda/microphysics/helm_eos_loader.cpp.o"
  "CMakeFiles/arch_cuda_backend.dir/src/cuda/microphysics/helm_eos_loader.cpp.o.d"
  "CMakeFiles/arch_cuda_backend.dir/src/cuda/runtime/CudaBackend.cu.o"
  "CMakeFiles/arch_cuda_backend.dir/src/cuda/runtime/CudaBackend.cu.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA CXX)
  include(CMakeFiles/arch_cuda_backend.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
