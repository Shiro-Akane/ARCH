file(REMOVE_RECURSE
  "CMakeFiles/arch_cuda_hydro_block.dir/tests/cuda/test_cuda_hydro_block.cu.o"
  "CMakeFiles/arch_cuda_hydro_block.dir/tests/cuda/test_cuda_hydro_block.cu.o.d"
  "arch_cuda_hydro_block"
  "arch_cuda_hydro_block.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA CXX)
  include(CMakeFiles/arch_cuda_hydro_block.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
