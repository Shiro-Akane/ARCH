# Empty compiler generated dependencies file for arch_cuda_burn_policy_parity_strict.
# This may be replaced when dependencies are built.
