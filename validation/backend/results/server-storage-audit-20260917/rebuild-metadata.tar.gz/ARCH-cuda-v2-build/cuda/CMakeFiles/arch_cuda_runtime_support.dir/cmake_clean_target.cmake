file(REMOVE_RECURSE
  "libarch_cuda_runtime_support.a"
)
