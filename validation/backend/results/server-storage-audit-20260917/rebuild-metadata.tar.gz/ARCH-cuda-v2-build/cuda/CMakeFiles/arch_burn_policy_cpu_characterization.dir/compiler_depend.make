# Empty compiler generated dependencies file for arch_burn_policy_cpu_characterization.
# This may be replaced when dependencies are built.
