file(REMOVE_RECURSE
  "CMakeFiles/arch_cuda_runtime_support.dir/src/numerics/diffusion/DiffFunction.cpp.o"
  "CMakeFiles/arch_cuda_runtime_support.dir/src/numerics/diffusion/DiffFunction.cpp.o.d"
  "libarch_cuda_runtime_support.a"
  "libarch_cuda_runtime_support.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/arch_cuda_runtime_support.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
