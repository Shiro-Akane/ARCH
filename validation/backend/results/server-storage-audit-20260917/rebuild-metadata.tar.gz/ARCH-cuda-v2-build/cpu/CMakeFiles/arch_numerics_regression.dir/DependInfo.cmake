
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/src/numerics/diffusion/DiffFunction.cpp" "CMakeFiles/arch_numerics_regression.dir/src/numerics/diffusion/DiffFunction.cpp.o" "gcc" "CMakeFiles/arch_numerics_regression.dir/src/numerics/diffusion/DiffFunction.cpp.o.d"
  "/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/src/physics/eos/Tabular3DEOS.cpp" "CMakeFiles/arch_numerics_regression.dir/src/physics/eos/Tabular3DEOS.cpp.o" "gcc" "CMakeFiles/arch_numerics_regression.dir/src/physics/eos/Tabular3DEOS.cpp.o.d"
  "/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/src/physics/eos/Tabular4DEOS.cpp" "CMakeFiles/arch_numerics_regression.dir/src/physics/eos/Tabular4DEOS.cpp.o" "gcc" "CMakeFiles/arch_numerics_regression.dir/src/physics/eos/Tabular4DEOS.cpp.o.d"
  "/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/tests/NumericsRegression.cpp" "CMakeFiles/arch_numerics_regression.dir/tests/NumericsRegression.cpp.o" "gcc" "CMakeFiles/arch_numerics_regression.dir/tests/NumericsRegression.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
