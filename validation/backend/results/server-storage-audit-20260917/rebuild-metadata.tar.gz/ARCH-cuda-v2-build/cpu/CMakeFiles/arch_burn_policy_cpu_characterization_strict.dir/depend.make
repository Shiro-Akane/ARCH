# Empty dependencies file for arch_burn_policy_cpu_characterization_strict.
# This may be replaced when dependencies are built.
