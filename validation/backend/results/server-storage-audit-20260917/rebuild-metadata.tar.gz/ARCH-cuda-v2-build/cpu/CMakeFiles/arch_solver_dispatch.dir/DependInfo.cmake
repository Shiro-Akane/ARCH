
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/ubuntu/projects/ARCH-cuda-v2-build/cpu/CMakeFiles/arch_solver_dispatch.dir/cmake_pch.hxx.cxx" "CMakeFiles/arch_solver_dispatch.dir/cmake_pch.hxx.gch" "gcc" "CMakeFiles/arch_solver_dispatch.dir/cmake_pch.hxx.gch.d"
  "/home/ubuntu/projects/ARCH-cuda-v2-build/cpu/CMakeFiles/arch_solver_dispatch.dir/cmake_pch.hxx" "CMakeFiles/arch_solver_dispatch.dir/cmake_pch.hxx.gch" "gcc" "CMakeFiles/arch_solver_dispatch.dir/cmake_pch.hxx.gch.d"
  "/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/src/driver/SolverDispatch.cpp" "CMakeFiles/arch_solver_dispatch.dir/src/driver/SolverDispatch.cpp.o" "gcc" "CMakeFiles/arch_solver_dispatch.dir/src/driver/SolverDispatch.cpp.o.d"
  "/home/ubuntu/projects/ARCH-cuda-v2-build/cpu/CMakeFiles/arch_solver_dispatch.dir/cmake_pch.hxx" "CMakeFiles/arch_solver_dispatch.dir/src/driver/SolverDispatch.cpp.o" "gcc" "CMakeFiles/arch_solver_dispatch.dir/src/driver/SolverDispatch.cpp.o.d"
  "/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/src/driver/dispatch/Dispatch_Euler.cpp" "CMakeFiles/arch_solver_dispatch.dir/src/driver/dispatch/Dispatch_Euler.cpp.o" "gcc" "CMakeFiles/arch_solver_dispatch.dir/src/driver/dispatch/Dispatch_Euler.cpp.o.d"
  "/home/ubuntu/projects/ARCH-cuda-v2-build/cpu/CMakeFiles/arch_solver_dispatch.dir/cmake_pch.hxx" "CMakeFiles/arch_solver_dispatch.dir/src/driver/dispatch/Dispatch_Euler.cpp.o" "gcc" "CMakeFiles/arch_solver_dispatch.dir/src/driver/dispatch/Dispatch_Euler.cpp.o.d"
  "/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/src/driver/dispatch/Dispatch_RK2.cpp" "CMakeFiles/arch_solver_dispatch.dir/src/driver/dispatch/Dispatch_RK2.cpp.o" "gcc" "CMakeFiles/arch_solver_dispatch.dir/src/driver/dispatch/Dispatch_RK2.cpp.o.d"
  "/home/ubuntu/projects/ARCH-cuda-v2-build/cpu/CMakeFiles/arch_solver_dispatch.dir/cmake_pch.hxx" "CMakeFiles/arch_solver_dispatch.dir/src/driver/dispatch/Dispatch_RK2.cpp.o" "gcc" "CMakeFiles/arch_solver_dispatch.dir/src/driver/dispatch/Dispatch_RK2.cpp.o.d"
  "/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/src/driver/dispatch/Dispatch_RK3.cpp" "CMakeFiles/arch_solver_dispatch.dir/src/driver/dispatch/Dispatch_RK3.cpp.o" "gcc" "CMakeFiles/arch_solver_dispatch.dir/src/driver/dispatch/Dispatch_RK3.cpp.o.d"
  "/home/ubuntu/projects/ARCH-cuda-v2-build/cpu/CMakeFiles/arch_solver_dispatch.dir/cmake_pch.hxx" "CMakeFiles/arch_solver_dispatch.dir/src/driver/dispatch/Dispatch_RK3.cpp.o" "gcc" "CMakeFiles/arch_solver_dispatch.dir/src/driver/dispatch/Dispatch_RK3.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
