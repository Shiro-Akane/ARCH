# Empty dependencies file for ARCH.
# This may be replaced when dependencies are built.
