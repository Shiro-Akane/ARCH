# Empty dependencies file for arch_numerics_regression_strict.
# This may be replaced when dependencies are built.
