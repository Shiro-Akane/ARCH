# Empty dependencies file for arch_compute_backend_test.
# This may be replaced when dependencies are built.
