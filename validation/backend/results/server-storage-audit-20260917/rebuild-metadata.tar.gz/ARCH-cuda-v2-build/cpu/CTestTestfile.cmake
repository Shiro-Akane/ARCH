# CMake generated Testfile for 
# Source directory: /home/ubuntu/projects/ARCH-cuda-v2-recovery-test
# Build directory: /home/ubuntu/projects/ARCH-cuda-v2-build/cpu
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(compute_backend "/home/ubuntu/projects/ARCH-cuda-v2-build/cpu/arch_compute_backend_test")
set_tests_properties(compute_backend PROPERTIES  _BACKTRACE_TRIPLES "/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/CMakeLists.txt;259;add_test;/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/CMakeLists.txt;0;")
add_test(compute_backend_cpu_binary_rejects_cuda "/home/ubuntu/projects/ARCH-cuda-v2-build/cpu/arch_compute_backend_test" "--cpu-binary-integration")
set_tests_properties(compute_backend_cpu_binary_rejects_cuda PROPERTIES  _BACKTRACE_TRIPLES "/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/CMakeLists.txt;262;add_test;/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/CMakeLists.txt;0;")
add_test(numerics_regression "/home/ubuntu/projects/ARCH-cuda-v2-build/cpu/arch_numerics_regression")
set_tests_properties(numerics_regression PROPERTIES  _BACKTRACE_TRIPLES "/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/CMakeLists.txt;299;add_test;/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/CMakeLists.txt;0;")
add_test(numerics_regression_strict "/home/ubuntu/projects/ARCH-cuda-v2-build/cpu/arch_numerics_regression_strict")
set_tests_properties(numerics_regression_strict PROPERTIES  _BACKTRACE_TRIPLES "/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/CMakeLists.txt;300;add_test;/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/CMakeLists.txt;0;")
add_test(burn_policy_cpu_characterization "/home/ubuntu/projects/ARCH-cuda-v2-build/cpu/arch_burn_policy_cpu_characterization")
set_tests_properties(burn_policy_cpu_characterization PROPERTIES  _BACKTRACE_TRIPLES "/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/CMakeLists.txt;327;add_test;/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/CMakeLists.txt;0;")
add_test(burn_policy_cpu_characterization_strict "/home/ubuntu/projects/ARCH-cuda-v2-build/cpu/arch_burn_policy_cpu_characterization_strict")
set_tests_properties(burn_policy_cpu_characterization_strict PROPERTIES  _BACKTRACE_TRIPLES "/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/CMakeLists.txt;329;add_test;/home/ubuntu/projects/ARCH-cuda-v2-recovery-test/CMakeLists.txt;0;")
