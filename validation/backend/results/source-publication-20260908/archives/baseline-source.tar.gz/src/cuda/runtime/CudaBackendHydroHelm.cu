#include "physics/eos/HelmEos.h"
#define ARCH_CUDA_HYDRO_EOS_TYPE HelmEosView
#include "CudaBackendHydroInstantiation.cuh"
