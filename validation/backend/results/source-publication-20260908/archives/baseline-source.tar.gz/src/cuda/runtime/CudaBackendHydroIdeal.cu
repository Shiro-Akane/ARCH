#include "physics/eos/IdealGas.h"
#define ARCH_CUDA_HYDRO_EOS_TYPE IdealGasView
#include "CudaBackendHydroInstantiation.cuh"
