/**
 * @file EOS_Utils.h
 * @brief Common thermodynamic and kinematic utilities for EOS solvers.
 */
#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <stdexcept>

#include "../../core/ArchPortability.h"
#include "../../core/CompensatedSum.h"
#include "eos.h" // Provides FluidVector through the EOS policy surface.

#ifndef EOS_INLINE
#define EOS_INLINE inline
#endif

namespace eos_utils
{
    // Derivatives in two linear composition coordinates q_a=sum(w_ai X_i).
    // The EOS owns its coordinates/interpolation; the chain rule is shared.
    struct LinearCompositionDerivatives
    {
        std::array<double, 2> energy{}, energy_temperature{}, cv{};
        std::array<double, 3> energy_hessian{}; // 00, 01, 11
        double cv_temperature = 0.0;
    };

    struct BilinearValue
    {
        double value, first, second, mixed;
    };

    ARCH_INLINE BilinearValue bilinear_value(
        double f00, double f01, double f10, double f11,
        double first_fraction, double second_fraction,
        double first_spacing, double second_spacing)
    {
        const double lower = f00 + second_fraction * (f01 - f00);
        const double upper = f10 + second_fraction * (f11 - f10);
        return {lower + first_fraction * (upper - lower),
                (upper - lower) / first_spacing,
                ((f01 - f00) * (1.0 - first_fraction) + (f11 - f10) * first_fraction) / second_spacing,
                ((f11 - f10) - (f01 - f00)) / (first_spacing * second_spacing)};
    }

    enum class CompositionQuery { energy_gradient, cv_gradient, energy_hessian_action };

    template <int Equations, CompositionQuery Query, class View>
    ARCH_HEAVY_INLINE void composition_derivative_query(
        const View& view, double rho, double temperature, const double* fractions,
        double* output, const double* flow = nullptr)
    {
        const auto d = view.composition_derivatives(rho, temperature, fractions);
        std::array<double, 2> coefficients{};
        if constexpr (Query == CompositionQuery::energy_gradient) {
            coefficients = d.energy;
        } else if constexpr (Query == CompositionQuery::cv_gradient) {
            coefficients = d.cv;
            output[Equations - 1] = d.cv_temperature;
        } else {
            arch::math::CompensatedSum first, second;
            for (int i = 0; i < Equations - 1; ++i) {
                const auto weights = view.composition_weights(i);
                first.add_product(weights[0], flow[i]);
                second.add_product(weights[1], flow[i]);
            }
            coefficients = {
                d.energy_hessian[0] * first.value() + d.energy_hessian[1] * second.value(),
                d.energy_hessian[1] * first.value() + d.energy_hessian[2] * second.value()};
            output[Equations - 1] = d.energy_temperature[0] * first.value()
                                  + d.energy_temperature[1] * second.value();
        }
        for (int i = 0; i < Equations - 1; ++i) {
            const auto weights = view.composition_weights(i);
            output[i] = coefficients[0] * weights[0] + coefficients[1] * weights[1];
        }
    }

    /** Thermodynamic point reached along a fixed-composition isentrope. */
    struct IsentropicState
    {
        double rho = 0.0;
        double temperature = 0.0;
        double pressure = 0.0;
        double sound_speed = 0.0;
    };

    // Shared kinetic/internal-energy conversions.
    ARCH_INLINE double calc_kinetic_energy(double rho, double u, double v, double w)
    {
        return 0.5 * rho * (u * u + v * v + w * w);
    }

    // Extract specific internal energy from a conservative state.
    ARCH_INLINE double extract_specific_internal_energy(const FluidVector &U)
    {
        if (U.rho < 1e-12)
            return 0.0;
        double kinetic_density = 0.5 * (U.mom_u * U.mom_u + U.mom_v * U.mom_v + U.mom_w * U.mom_w) / U.rho;
        return (U.eng - kinetic_density) / U.rho;
    }

    /** Estimate (dP/drho)_e without accidentally holding temperature fixed. */
    template <typename TEOSView>
    ARCH_INLINE double finite_difference_dp_drho_e(
        const TEOSView &eos_view, double rho, double specific_energy,
        const double *mass_fractions, double rho_min, double rho_max)
    {
        const double delta = std::max(1.0e-3 * std::abs(rho), 1.0e-300);
        const double lower = std::max(rho - delta, rho_min);
        const double upper = std::min(rho + delta, rho_max);
        if (!(upper > lower)) {
#if defined(__CUDA_ARCH__)
            return std::numeric_limits<double>::quiet_NaN();
#else
            throw std::runtime_error(
                "Tabular EOS cannot difference density at constant energy.");
#endif
        }
        const double pressure_lower = eos_view.get_pressure_from_rho_e(
            lower, specific_energy, mass_fractions);
        const double pressure_upper = eos_view.get_pressure_from_rho_e(
            upper, specific_energy, mass_fractions);
        const double derivative =
            (pressure_upper - pressure_lower) / (upper - lower);
        if (!std::isfinite(derivative)) {
#if defined(__CUDA_ARCH__)
            return std::numeric_limits<double>::quiet_NaN();
#else
            throw std::runtime_error(
                "Tabular EOS produced a non-finite constant-energy derivative.");
#endif
        }
        return derivative;
    }

    // Generic Newton pressure inversion for three- and four-dimensional tables.
    // TEOSView must provide get_pressure_from_rho_e and get_dp_de_rho.
    template <typename TEOSView>
    ARCH_INLINE double solve_total_energy(const TEOSView &eos_view,
                                         double rho, double u, double v, double w,
                                         double target_p, const double *Xi)
    {
        // Initialize with the gamma=1.4 ideal-gas estimate. This is a numerical
        // seed only; all accepted iterates use the selected tabular EOS.
        double e_guess = target_p / ((1.4 - 1.0) * rho);

        for (int iter = 0; iter < 20; ++iter)
        {
            double p_guess = eos_view.get_pressure_from_rho_e(rho, e_guess, Xi);
            double dp_de = eos_view.get_dp_de_rho(rho, e_guess, Xi);

            if (std::abs(dp_de) < 1e-12)
                break;

            double delta_e = (target_p - p_guess) / dp_de;

            // Backtrack until the trial specific internal energy remains above
            // the 1e-12 positivity floor.
            while (e_guess + delta_e <= 1e-12)
            {
                delta_e *= 0.5;
            }
            e_guess += delta_e;

            if (std::abs(delta_e) < 1e-6 * e_guess)
                break;
        }

        return rho * e_guess + calc_kinetic_energy(rho, u, v, w);
    }

    /**
     * Move a (rho,T,X) reference state to a requested pressure factor while
     * holding composition and specific entropy fixed.
     *
     * Every EOS policy obtains the same implementation through its required
     * evaluate_state(eos_state_t&) surface.  The thermodynamic path obeys
     *
     *   d ln(T) / d ln(rho) |_s,X = (dP/dT)_rho,X / (rho c_v)
     *
     * and a Newton solve in ln(rho), using Gamma1=rho*c_s^2/P, matches the
     * target pressure.  This is a local-state construction: the accepted
     * solution may not move farther than 0.25 in ln(rho) from the reference.
     */
    template <typename TEOSPolicy>
    IsentropicState get_isentropic_state_at_pressure_factor(
        const TEOSPolicy &eos,
        double reference_rho,
        double reference_temperature,
        const double *mass_fractions,
        double pressure_factor)
    {
        if (!std::isfinite(reference_rho) || reference_rho <= 0.0 ||
            !std::isfinite(reference_temperature) || reference_temperature <= 0.0 ||
            !std::isfinite(pressure_factor) || pressure_factor <= 0.0) {
            throw std::invalid_argument(
                "Invalid reference state or pressure factor for isentropic initialization.");
        }

        const auto evaluate = [&](double rho, double temperature) {
            eos_state_t state{};
            state.rho = rho;
            state.T = temperature;
            state.Xi = mass_fractions;
            eos.evaluate_state(state);
            if (!std::isfinite(state.P) || state.P <= 0.0 ||
                !std::isfinite(state.cv) || state.cv <= 0.0 ||
                !std::isfinite(state.dp_dT) ||
                !std::isfinite(state.sound_speed) || state.sound_speed <= 0.0) {
                throw std::runtime_error(
                    "EOS returned an invalid state while integrating an isentrope.");
            }
            return state;
        };

        const eos_state_t reference = evaluate(reference_rho, reference_temperature);
        const double target_pressure = pressure_factor * reference.P;
        if (!std::isfinite(target_pressure) || target_pressure <= 0.0) {
            throw std::invalid_argument("Isentropic target pressure is not finite and positive.");
        }

        const double log_rho_reference = std::log(reference_rho);
        const double log_temperature_reference = std::log(reference_temperature);
        constexpr double max_log_density_distance = 0.25;

        const auto log_temperature_on_isentrope = [&](double log_rho_target) {
            const double interval = log_rho_target - log_rho_reference;
            if (std::abs(interval) > max_log_density_distance) {
                throw std::runtime_error(
                    "Isentropic pressure solve left its supported local neighborhood.");
            }
            const int steps = std::max(
                8, static_cast<int>(std::ceil(std::abs(interval) / 1.0e-4)));
            const double step = interval / static_cast<double>(steps);
            double log_rho = log_rho_reference;
            double log_temperature = log_temperature_reference;

            const auto derivative = [&](double x, double y) {
                const eos_state_t state = evaluate(std::exp(x), std::exp(y));
                return state.dp_dT / (state.rho * state.cv);
            };
            for (int index = 0; index < steps; ++index) {
                const double k1 = derivative(log_rho, log_temperature);
                const double k2 = derivative(
                    log_rho + 0.5 * step, log_temperature + 0.5 * step * k1);
                const double k3 = derivative(
                    log_rho + 0.5 * step, log_temperature + 0.5 * step * k2);
                const double k4 = derivative(
                    log_rho + step, log_temperature + step * k3);
                log_temperature += step * (k1 + 2.0 * k2 + 2.0 * k3 + k4) / 6.0;
                log_rho += step;
            }
            return log_temperature;
        };

        const double gamma1_reference = reference_rho * reference.sound_speed *
                                        reference.sound_speed / reference.P;
        if (!std::isfinite(gamma1_reference) || gamma1_reference <= 0.0) {
            throw std::runtime_error("EOS returned an invalid reference adiabatic exponent.");
        }

        double log_rho = log_rho_reference + std::log(pressure_factor) / gamma1_reference;
        eos_state_t state{};
        for (int iteration = 0; iteration < 12; ++iteration) {
            const double temperature = std::exp(log_temperature_on_isentrope(log_rho));
            state = evaluate(std::exp(log_rho), temperature);
            const double residual = std::log(state.P / target_pressure);
            if (std::abs(residual) <= 2.0e-13) {
                return {
                    state.rho,
                    state.T,
                    state.P,
                    state.sound_speed,
                };
            }
            const double gamma1 = state.rho * state.sound_speed *
                                  state.sound_speed / state.P;
            if (!std::isfinite(gamma1) || gamma1 <= 0.0) {
                throw std::runtime_error("EOS returned an invalid adiabatic exponent.");
            }
            log_rho -= residual / gamma1;
        }

        throw std::runtime_error("Isentropic pressure initialization did not converge.");
    }
}
